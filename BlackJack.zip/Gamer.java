package com.green.java.blackjack;

public class Gamer extends User {


}
